package reflection;

import static org.junit.Assert.assertEquals;


import org.junit.jupiter.api.Test;

class TestMyClass {

	@Test
	void test() {
		int r = new Myclass().main() ; 
		assertEquals(84, r) ; 
	}

}
