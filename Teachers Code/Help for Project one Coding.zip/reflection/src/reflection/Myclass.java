package reflection;

import java.lang.reflect.*;

public class Myclass {
	public static int main()
    {
	      Integer retval =null ; 
		try {
         Class cls = Class.forName("reflection.Class1");
        
         Class partypes[] = new Class[2];
         
          partypes[0] = Integer.TYPE;
          partypes[1] = Integer.TYPE;
          
          
          Method classMethod = cls.getMethod( "add", partypes);
           
          Class1 class1 = new Class1();
          
          Object arglist[] = new Object[2];
          arglist[0] = 37;
          arglist[1] = 47;
          
          
          Object retobj = classMethod.invoke(class1, arglist);
          
          
          retval = (Integer)retobj;
          System.out.println(retval.intValue());
          
         
       }
       catch (Throwable e) {
          System.err.println(e);
       }
       return retval.intValue() ; 
    }
}